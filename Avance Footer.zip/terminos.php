<!DOCTYPE html>
<html lang="es">
<?php include ("./assets/fragmentos/head.php");?>
<body>
    <?php include ("./assets/fragmentos/header.php"); ?>

    <?php include ("./assets/fragmentos/losterminos.php"); ?>

    <?php include ("./assets/fragmentos/footer.php"); ?>
</body>
    <?php include ("./assets/fragmentos/scripts.php"); ?>
</html>